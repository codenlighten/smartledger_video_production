export const postcssConfig = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}

export default postcssConfig
